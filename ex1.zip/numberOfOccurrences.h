#include <iostream>

int numberOfOccurrences(const std::string &text, const std::string &subtext);
