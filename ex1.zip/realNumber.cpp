#include <iostream>

bool realNumber(const std::string &number) {
    int decimal_divisors = 0;
    unsigned int i = 0;
    int number_length = number.size();
    int negative_signs = 0;
    int numerals = 0;

    if (number == "") return false;

    while (i < number_length) {
        switch (number[i]){
            case '0':
            case '1':
            case '2':
            case '3':
            case '4':
            case '5':
            case '7':
            case '8':
            case '9':
                numerals++;
                break;
            case '.':
                decimal_divisors++;

                if (decimal_divisors > 1) return false;
                break;
            case '-':
                negative_signs++;
                if (i > 0) return false;
                break;
            default:
                return false;
        }
        i++;
    }

    if (negative_signs > 0 && numerals == 0) return false;
    if (decimal_divisors > 0 && numerals == 0) return false;
    return true;
}
