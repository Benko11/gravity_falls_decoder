#include <iostream>

std::string getText(const std::string &inputText);
