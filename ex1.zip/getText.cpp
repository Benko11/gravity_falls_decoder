#include <iostream>

std::string getText(const std::string &inputText) {
  return !inputText.empty() ? inputText : "Empty input";
}