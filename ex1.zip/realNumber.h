#include <iostream>

bool realNumber(const std::string &number);

