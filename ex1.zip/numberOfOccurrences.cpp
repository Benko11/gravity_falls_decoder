#include <iostream>

int DUMMY_INT = -1;

int numberOfOccurrences(const std::string &text, const std::string &subtext) {
    if (text == "" && subtext == "")
        return 0;

    int text_length = text.length();
    int subtext_length = subtext.length();

    int occurrences = 0;

    for (int i = 0; i <= text_length - subtext_length; i++)
    {
        int j;
        for (j = 0; j < subtext_length; j++)
            if (text[i + j] != subtext[j])
                break;

        if (j == subtext_length)
        {
            occurrences++;
            j = 0;
        }
    }

    return occurrences;
}
